# Public-domain scope

Except where otherwise noted, all original contributions to this repository
are dedicated to the public domain under
[CC0 1.0 Universal](https://creativecommons.org/publicdomain/zero/1.0/), to
the extent that copyright or related rights subsist and are held by the
repository owner or contributors.

This includes original:

- prose, mathematical exposition, documentation, and release metadata;
- source code and scripts;
- generated datasets, catalogue outputs, and logs;
- SAT instances and proof certificates; and
- document text, typesetting, and layout.

The complete, unmodified CC0 legal text is in [`LICENSE`](LICENSE).

## Material outside the dedication

CC0 applies only to rights that the affirmer has authority to waive. It does
not relicense third-party material.

In particular:

- Font software embedded in `z20_walkthrough.pdf` and
  `paper/z20_equals_6_proof.pdf` remains under the respective font licences.
  The PDFs' original text and layout are covered by the dedication.
- Third-party tools referenced for reproduction—including nauty and `geng`,
  DRAT-trim, CakeML and `cake_lpr`, NumPy, Pandoc, and LaTeX—are not vendored
  here and retain their own licences.
- The dedication does not apply to cited publications, linked external
  material, trademarks, patents, privacy or publicity rights, or any other
  rights held by third parties.

Mathematical facts, ideas, algorithms, and mechanically generated outputs
may not be copyrightable. CC0 applies to them only to the extent copyright or
related rights exist and the affirmer has authority to waive them.

## Reuse

No attribution is required by CC0. Preserving the candidate-status notice,
artifact hashes, and provenance is nevertheless encouraged because it lets
future readers distinguish exact reuse from independent mathematical or
computational verification.
